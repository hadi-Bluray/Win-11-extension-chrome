// ---------- Data ----------
const DEFAULT_SITES = [
  { name: "Google", url: "https://www.google.com" },
  { name: "YouTube", url: "https://www.youtube.com" },
  { name: "Gmail", url: "https://mail.google.com" },
  { name: "GitHub", url: "https://github.com" },
  { name: "Wikipedia", url: "https://wikipedia.org" },
  { name: "Instagram", url: "https://www.instagram.com" },
  { name: "Telegram", url: "https://web.telegram.org" },
  { name: "X", url: "https://x.com" },
  { name: "LinkedIn", url: "https://www.linkedin.com" },
  { name: "Spotify", url: "https://open.spotify.com" },
  { name: "Maps", url: "https://www.google.com/maps" },
  { name: "Translate", url: "https://translate.google.com" },
];

const I18N = {
  fa: {
    title: "تب جدید", search: "جستجو در وب...", startSearch: "جستجو...", pinned: "سایت‌های منتخب",
    settings: "تنظیمات", language: "زبان", engine: "موتور جستجو", calendar: "تقویم",
    persian: "شمسی", gregorian: "میلادی", hour24: "ساعت ۲۴ ساعته", seconds: "نمایش ثانیه",
    showShortcuts: "نمایش میانبرها", blur: "تاری پس‌زمینه", reset: "بازگردانی پیش‌فرض",
    start: "استارت", searchBtn: "جستجو", user: "کاربر", widgets: "ویجت‌ها", city: "شهر (آب‌وهوا)",
    wallpaper: "تصویر زمینه", choose: "انتخاب", default: "پیش‌فرض",
    addSite: "افزودن سایت", editSite: "ویرایش سایت", removeSite: "حذف سایت", openNew: "باز کردن در تب جدید",
    changeWallpaper: "تغییر تصویر زمینه", resetWallpaper: "تصویر زمینه پیش‌فرض", refresh: "بارگذاری مجدد",
    siteName: "نام", siteUrl: "آدرس", save: "ذخیره", cancel: "انصراف",
    wNotes: "یادداشت", wTodo: "کارها", wCalendar: "تقویم", wWeather: "آب‌وهوا", wClock: "ساعت جهانی",
    notesPh: "اینجا بنویسید...", todoPh: "کار جدید + Enter", loading: "در حال دریافت...", weatherErr: "دریافت آب‌وهوا ممکن نشد",
    tooBig: "این تصویر برای ذخیره خیلی بزرگ است.", confirmRemove: "این سایت حذف شود؟",
    days: ["ش", "ی", "د", "س", "چ", "پ", "ج"],
  },
  en: {
    title: "New Tab", search: "Search the web...", startSearch: "Search...", pinned: "Pinned sites",
    settings: "Settings", language: "Language", engine: "Search engine", calendar: "Calendar",
    persian: "Persian (Solar)", gregorian: "Gregorian", hour24: "24-hour clock", seconds: "Show seconds",
    showShortcuts: "Show shortcuts", blur: "Wallpaper blur", reset: "Reset to defaults",
    start: "Start", searchBtn: "Search", user: "User", widgets: "Widgets", city: "City (weather)",
    wallpaper: "Wallpaper", choose: "Choose", default: "Default",
    addSite: "Add site", editSite: "Edit site", removeSite: "Remove site", openNew: "Open in new tab",
    changeWallpaper: "Change wallpaper", resetWallpaper: "Default wallpaper", refresh: "Refresh",
    siteName: "Name", siteUrl: "URL", save: "Save", cancel: "Cancel",
    wNotes: "Notes", wTodo: "To-do", wCalendar: "Calendar", wWeather: "Weather", wClock: "World clock",
    notesPh: "Write here...", todoPh: "New task + Enter", loading: "Loading...", weatherErr: "Couldn't load weather",
    tooBig: "This image is too large to save.", confirmRemove: "Remove this site?",
    days: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
  },
};

const ENGINES = {
  google: "https://www.google.com/search?q=",
  bing: "https://www.bing.com/search?q=",
  duck: "https://duckduckgo.com/?q=",
};
const WIDGETS = ["weather", "clock", "calendar", "todo", "notes"];

const DEFAULTS = {
  lang: "fa", engine: "google", cal: "persian", h24: true, sec: false, short: true, blur: 0,
  city: "Tehran", widgets: { weather: true, clock: true, calendar: true, todo: true, notes: true },
};

let S = structuredClone(DEFAULTS);
let SITES = DEFAULT_SITES.slice();
let NOTES = "";
let TODOS = [];
let WALLPAPER = null;

// ---------- Storage (chrome.storage.local, falls back to localStorage) ----------
const hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
const store = {
  get(keys) {
    if (hasChrome) return new Promise((r) => chrome.storage.local.get(keys, r));
    const out = {};
    keys.forEach((k) => { const v = localStorage.getItem(k); if (v != null) out[k] = JSON.parse(v); });
    return Promise.resolve(out);
  },
  set(obj) {
    if (hasChrome) return new Promise((r) => chrome.storage.local.set(obj, r));
    try { Object.entries(obj).forEach(([k, v]) => localStorage.setItem(k, JSON.stringify(v))); return Promise.resolve(); }
    catch (e) { return Promise.reject(e); }
  },
  remove(k) {
    if (hasChrome) return new Promise((r) => chrome.storage.local.remove(k, r));
    localStorage.removeItem(k); return Promise.resolve();
  },
};
const saveSettings = () => store.set({ settings: S });
const saveSites = () => store.set({ sites: SITES });

const $ = (id) => document.getElementById(id);
const t = () => I18N[S.lang];
const locale = () => `${S.lang === "fa" ? "fa-IR" : "en-US"}-u-ca-${S.cal}`;

function normUrl(u) {
  u = u.trim();
  return /^https?:\/\//i.test(u) ? u : "https://" + u;
}
function hostOf(u) { try { return new URL(normUrl(u)).hostname; } catch { return ""; } }
function faviconUrl(u) { return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(hostOf(u))}&sz=64`; }

// ---------- Clock ----------
function tick() {
  const now = new Date();
  const opts = { hour: "2-digit", minute: "2-digit", hour12: !S.h24 };
  if (S.sec) opts.second = "2-digit";
  $("clock").textContent = now.toLocaleTimeString(locale(), opts);
  $("date").textContent = now.toLocaleDateString(locale(), { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  $("trayTime").textContent = now.toLocaleTimeString(locale(), { hour: "2-digit", minute: "2-digit", hour12: !S.h24 });
  $("trayDate").textContent = now.toLocaleDateString(locale());
  document.querySelectorAll("[data-tz]").forEach((el) => {
    el.textContent = now.toLocaleTimeString(locale(), { hour: "2-digit", minute: "2-digit", hour12: !S.h24, timeZone: el.dataset.tz });
  });
}

// ---------- Site tiles ----------
function icon(site, size) {
  const img = document.createElement("img");
  img.className = "tile"; img.width = size; img.height = size; img.alt = ""; img.draggable = false;
  img.src = faviconUrl(site.url);
  img.onerror = () => {
    const d = document.createElement("div");
    d.className = "tile letter"; d.textContent = (site.name || "?")[0].toUpperCase();
    img.replaceWith(d);
  };
  return img;
}
function link(site, cls, index) {
  const a = document.createElement("a");
  a.className = cls; a.href = normUrl(site.url); a.dataset.index = index;
  a.appendChild(icon(site, cls === "shortcut" ? 40 : 32));
  a.appendChild(Object.assign(document.createElement("span"), { textContent: site.name }));
  if (cls === "shortcut") enableDrag(a);
  return a;
}

// Drag & drop reorder
let dragFrom = null;
function enableDrag(el) {
  el.draggable = true;
  el.addEventListener("dragstart", (e) => { dragFrom = +el.dataset.index; el.classList.add("dragging"); e.dataTransfer.effectAllowed = "move"; });
  el.addEventListener("dragend", () => { el.classList.remove("dragging"); document.querySelectorAll(".drop-target").forEach((x) => x.classList.remove("drop-target")); });
  el.addEventListener("dragover", (e) => { e.preventDefault(); el.classList.add("drop-target"); });
  el.addEventListener("dragleave", () => el.classList.remove("drop-target"));
  el.addEventListener("drop", (e) => {
    e.preventDefault();
    const to = +el.dataset.index;
    if (dragFrom == null || dragFrom === to) return;
    const [moved] = SITES.splice(dragFrom, 1);
    SITES.splice(to, 0, moved);
    dragFrom = null;
    saveSites(); renderSites();
  });
}

function renderSites() {
  const sc = $("shortcuts");
  sc.innerHTML = "";
  sc.style.display = S.short ? "" : "none";
  SITES.forEach((s, i) => sc.appendChild(link(s, "shortcut", i)));
  const add = document.createElement("button");
  add.className = "shortcut add"; add.type = "button"; add.title = t().addSite;
  add.innerHTML = `<div class="tile letter plus">+</div><span></span>`;
  add.querySelector("span").textContent = t().addSite;
  add.onclick = () => openSiteDialog();
  sc.appendChild(add);

  const grid = $("startGrid");
  grid.innerHTML = "";
  SITES.forEach((s, i) => grid.appendChild(link(s, "start-item", i)));
}

// ---------- Wallpaper ----------
function applyWallpaper() {
  const w = $("wallpaper");
  w.style.backgroundImage = WALLPAPER ? `url("${WALLPAPER}")` : "";
  w.style.filter = S.blur ? `blur(${S.blur}px)` : "";
  w.style.transform = S.blur ? "scale(1.05)" : "";
}
function pickWallpaper() { $("wallpaperInput").click(); }
$("wallpaperInput").addEventListener("change", (e) => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  const img = new Image();
  const reader = new FileReader();
  reader.onload = () => {
    img.onload = async () => {
      // Downscale so it fits comfortably in browser storage
      const max = 2560, scale = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      const data = c.toDataURL("image/jpeg", 0.88);
      try { await store.set({ wallpaper: data }); WALLPAPER = data; applyWallpaper(); }
      catch { alert(t().tooBig); }
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
});
async function resetWallpaper() { WALLPAPER = null; await store.remove("wallpaper"); applyWallpaper(); }

// ---------- Site dialog ----------
let editingIndex = null;
function openSiteDialog(index = null) {
  closeAll();
  editingIndex = index;
  const s = index == null ? { name: "", url: "" } : SITES[index];
  $("siteTitle").textContent = index == null ? t().addSite : t().editSite;
  $("siteName").value = s.name; $("siteUrl").value = s.url;
  updatePreview();
  $("siteModal").classList.remove("hidden");
  setTimeout(() => $("siteUrl").focus(), 30);
}
function updatePreview() {
  const url = $("siteUrl").value, name = $("siteName").value;
  const ic = $("sitePreviewIcon");
  ic.style.visibility = hostOf(url) ? "visible" : "hidden";
  if (hostOf(url)) ic.src = faviconUrl(url);
  $("sitePreviewName").textContent = name || hostOf(url) || "—";
}
let previewTimer;
$("siteUrl").addEventListener("input", () => {
  clearTimeout(previewTimer);
  previewTimer = setTimeout(() => {
    if (!$("siteName").value && hostOf($("siteUrl").value)) {
      const h = hostOf($("siteUrl").value).replace(/^www\./, "").split(".")[0];
      $("siteName").placeholder = h.charAt(0).toUpperCase() + h.slice(1);
    }
    updatePreview();
  }, 250);
});
$("siteName").addEventListener("input", updatePreview);
$("siteForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const url = normUrl($("siteUrl").value);
  if (!hostOf(url)) return;
  const name = $("siteName").value.trim() || $("siteName").placeholder || hostOf(url);
  if (editingIndex == null) SITES.push({ name, url }); else SITES[editingIndex] = { name, url };
  saveSites(); renderSites();
  $("siteModal").classList.add("hidden");
});
function removeSite(i) {
  if (!confirm(t().confirmRemove)) return;
  SITES.splice(i, 1); saveSites(); renderSites();
}

// ---------- Context menu ----------
const ctx = $("ctxMenu");
function showCtx(x, y, items) {
  ctx.innerHTML = "";
  items.forEach((it) => {
    if (it === "-") { ctx.appendChild(Object.assign(document.createElement("hr"))); return; }
    const b = document.createElement("button");
    b.innerHTML = `<span class="ic">${it.icon}</span>`;
    b.appendChild(document.createTextNode(it.label));
    b.onclick = () => { ctx.classList.add("hidden"); it.run(); };
    ctx.appendChild(b);
  });
  ctx.classList.remove("hidden");
  const r = ctx.getBoundingClientRect();
  ctx.style.left = Math.min(x, innerWidth - r.width - 8) + "px";
  ctx.style.top = Math.min(y, innerHeight - r.height - 8) + "px";
}
document.addEventListener("contextmenu", (e) => {
  if (e.target.closest("input, textarea, .dialog")) return;
  e.preventDefault();
  closeAll();
  const site = e.target.closest(".shortcut[data-index], .start-item[data-index]");
  const T = t();
  if (site) {
    const i = +site.dataset.index;
    showCtx(e.clientX, e.clientY, [
      { icon: "↗", label: T.openNew, run: () => window.open(normUrl(SITES[i].url), "_blank") },
      { icon: "✎", label: T.editSite, run: () => openSiteDialog(i) },
      { icon: "🗑", label: T.removeSite, run: () => removeSite(i) },
    ]);
  } else {
    showCtx(e.clientX, e.clientY, [
      { icon: "+", label: T.addSite, run: () => openSiteDialog() },
      { icon: "🖼", label: T.changeWallpaper, run: pickWallpaper },
      { icon: "↺", label: T.resetWallpaper, run: resetWallpaper },
      "-",
      { icon: "▦", label: T.widgets, run: () => toggle("widgetsPanel") },
      { icon: "⚙", label: T.settings, run: () => toggle("settingsPanel") },
      { icon: "⟳", label: T.refresh, run: () => location.reload() },
    ]);
  }
});

// ---------- Widgets ----------
let weatherCache = null;
function renderWidgets() {
  const T = t();
  const toggles = $("widgetToggles");
  toggles.innerHTML = "";
  WIDGETS.forEach((w) => {
    const b = document.createElement("button");
    b.className = "chip" + (S.widgets[w] ? " on" : "");
    b.textContent = T["w" + w[0].toUpperCase() + w.slice(1)];
    b.onclick = () => { S.widgets[w] = !S.widgets[w]; saveSettings(); renderWidgets(); };
    toggles.appendChild(b);
  });

  const list = $("widgetList");
  list.innerHTML = "";
  WIDGETS.filter((w) => S.widgets[w]).forEach((w) => {
    const card = document.createElement("section");
    card.className = "widget";
    card.innerHTML = `<h4></h4><div class="body"></div>`;
    card.querySelector("h4").textContent = T["w" + w[0].toUpperCase() + w.slice(1)];
    const body = card.querySelector(".body");
    ({ weather: wWeather, clock: wClock, calendar: wCalendar, todo: wTodo, notes: wNotes })[w](body);
    list.appendChild(card);
  });
  tick();
}

function wWeather(body) {
  body.textContent = t().loading;
  const draw = (d) => {
    const codes = { 0: "☀️", 1: "🌤", 2: "⛅", 3: "☁️", 45: "🌫", 48: "🌫", 51: "🌦", 61: "🌧", 63: "🌧", 65: "🌧", 71: "🌨", 73: "🌨", 80: "🌦", 95: "⛈" };
    body.innerHTML = `<div class="weather"><span class="wi">${codes[d.code] || "🌡"}</span><b>${Math.round(d.temp)}°</b><span class="muted"></span></div>`;
    body.querySelector(".muted").textContent = d.city;
  };
  if (weatherCache && weatherCache.city === S.city && Date.now() - weatherCache.at < 15 * 60e3) return draw(weatherCache);
  fetch(`https://geocoding-api.open-meteo.com/v1/search?count=1&name=${encodeURIComponent(S.city)}`)
    .then((r) => r.json())
    .then((g) => {
      const p = g.results && g.results[0];
      if (!p) throw new Error("city");
      return fetch(`https://api.open-meteo.com/v1/forecast?latitude=${p.latitude}&longitude=${p.longitude}&current=temperature_2m,weather_code`)
        .then((r) => r.json()).then((w) => ({ city: S.city, name: p.name, temp: w.current.temperature_2m, code: w.current.weather_code }));
    })
    .then((d) => { weatherCache = { ...d, at: Date.now() }; draw(weatherCache); })
    .catch(() => { body.textContent = t().weatherErr; });
}

function wClock(body) {
  const zones = [["Tehran", "Asia/Tehran"], ["London", "Europe/London"], ["New York", "America/New_York"], ["Tokyo", "Asia/Tokyo"]];
  body.innerHTML = zones.map(([n, z]) => `<div class="tz"><span>${n}</span><b data-tz="${z}" dir="ltr"></b></div>`).join("");
}

function wCalendar(body) {
  const now = new Date();
  const loc = locale();
  const partNum = (d, type) => +new Intl.DateTimeFormat("en-US-u-ca-" + S.cal, { [type]: "numeric" }).formatToParts(d).find((p) => p.type === type).value;
  const today = partNum(now, "day");
  const first = new Date(now); first.setDate(now.getDate() - today + 1);
  // days in month: walk forward until month changes
  const month = partNum(now, "month");
  let len = 28; while (len < 32) { const d = new Date(first); d.setDate(first.getDate() + len); if (partNum(d, "month") !== month) break; len++; }
  const weekStart = S.cal === "persian" ? 6 : 0; // Saturday for Persian
  const offset = (first.getDay() - weekStart + 7) % 7;
  const order = S.cal === "persian" ? [6, 0, 1, 2, 3, 4, 5] : [0, 1, 2, 3, 4, 5, 6];
  const daysFa = ["ی", "د", "س", "چ", "پ", "ج", "ش"], daysEn = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
  const names = S.lang === "fa" ? daysFa : daysEn;
  const fmtNum = new Intl.NumberFormat(S.lang === "fa" ? "fa-IR" : "en-US");
  let html = `<div class="cal-title">${new Intl.DateTimeFormat(loc, { month: "long", year: "numeric" }).format(now)}</div><div class="cal">`;
  html += order.map((i) => `<span class="dn">${names[i]}</span>`).join("");
  html += "<span></span>".repeat(offset);
  for (let d = 1; d <= len; d++) html += `<span class="${d === today ? "today" : ""}">${fmtNum.format(d)}</span>`;
  body.innerHTML = html + "</div>";
}

function wTodo(body) {
  const input = Object.assign(document.createElement("input"), { className: "txt full", placeholder: t().todoPh });
  const ul = document.createElement("ul"); ul.className = "todo";
  const draw = () => {
    ul.innerHTML = "";
    TODOS.forEach((item, i) => {
      const li = document.createElement("li");
      const cb = Object.assign(document.createElement("input"), { type: "checkbox", checked: item.done });
      cb.onchange = () => { item.done = cb.checked; store.set({ todos: TODOS }); draw(); };
      const span = Object.assign(document.createElement("span"), { textContent: item.text, className: item.done ? "done" : "" });
      const del = Object.assign(document.createElement("button"), { textContent: "✕", className: "x" });
      del.onclick = () => { TODOS.splice(i, 1); store.set({ todos: TODOS }); draw(); };
      li.append(cb, span, del); ul.appendChild(li);
    });
  };
  input.onkeydown = (e) => {
    if (e.key === "Enter" && input.value.trim()) { TODOS.push({ text: input.value.trim(), done: false }); input.value = ""; store.set({ todos: TODOS }); draw(); }
  };
  draw();
  body.append(input, ul);
}

function wNotes(body) {
  const ta = Object.assign(document.createElement("textarea"), { className: "notes", placeholder: t().notesPh, value: NOTES });
  let timer;
  ta.oninput = () => { NOTES = ta.value; clearTimeout(timer); timer = setTimeout(() => store.set({ notes: NOTES }), 300); };
  body.appendChild(ta);
}

// ---------- Panels ----------
const PANELS = ["startMenu", "settingsPanel", "widgetsPanel", "ctxMenu"];
function closeAll(except) { PANELS.forEach((p) => p !== except && $(p).classList.add("hidden")); }
function toggle(id) {
  const open = $(id).classList.contains("hidden");
  closeAll(id);
  $(id).classList.toggle("hidden", !open);
  if (id === "widgetsPanel" && open) renderWidgets();
}
$("startBtn").addEventListener("click", (e) => { e.stopPropagation(); toggle("startMenu"); });
$("widgetsBtn").addEventListener("click", (e) => { e.stopPropagation(); toggle("widgetsPanel"); });
$("openSettings").addEventListener("click", (e) => { e.stopPropagation(); toggle("settingsPanel"); });
$("taskSearchBtn").addEventListener("click", () => $("searchInput").focus());
document.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => $(b.dataset.close).classList.add("hidden")));
document.querySelectorAll("[data-action]").forEach((b) => b.addEventListener("click", () => ({ pickWallpaper, resetWallpaper })[b.dataset.action]()));
document.addEventListener("click", (e) => {
  PANELS.forEach((p) => { if (!$(p).contains(e.target)) $(p).classList.add("hidden"); });
});
$("siteModal").addEventListener("click", (e) => { if (e.target.id === "siteModal") $("siteModal").classList.add("hidden"); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeAll(); $("siteModal").classList.add("hidden"); } });
PANELS.concat("siteModal").forEach((p) => $(p).addEventListener("click", (e) => { if (p !== "siteModal") e.stopPropagation(); }));

// ---------- Settings ----------
function render() {
  const T = t();
  document.documentElement.lang = S.lang;
  document.documentElement.dir = S.lang === "fa" ? "rtl" : "ltr";
  document.title = T.title;
  $("searchInput").placeholder = T.search;
  $("startSearch").placeholder = T.startSearch;
  $("startBtn").title = T.start;
  $("taskSearchBtn").title = T.searchBtn;
  $("widgetsBtn").title = T.widgets;
  document.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = T[el.dataset.i18n]; });
  $("setLang").value = S.lang;
  $("setEngine").value = S.engine;
  $("setCal").value = S.cal;
  $("setH24").checked = S.h24;
  $("setSec").checked = S.sec;
  $("setShort").checked = S.short;
  $("setBlur").value = S.blur;
  $("setCity").value = S.city;
  renderSites();
  applyWallpaper();
  if (!$("widgetsPanel").classList.contains("hidden")) renderWidgets();
  tick();
}
function bind(id, key, prop = "value", cast = (v) => v, ev = "input") {
  $(id).addEventListener(ev, (e) => { S[key] = cast(e.target[prop]); saveSettings(); render(); });
}
bind("setLang", "lang");
bind("setEngine", "engine");
bind("setCal", "cal");
bind("setH24", "h24", "checked");
bind("setSec", "sec", "checked");
bind("setShort", "short", "checked");
bind("setBlur", "blur", "value", Number);
bind("setCity", "city", "value", (v) => v.trim() || "Tehran", "change");
$("resetSettings").addEventListener("click", () => { S = structuredClone(DEFAULTS); saveSettings(); render(); });

// ---------- Search ----------
function go(q) {
  const isUrl = /^https?:\/\//.test(q) || (/^[\w-]+(\.[\w-]+)+/.test(q) && !q.includes(" "));
  location.href = isUrl ? normUrl(q) : ENGINES[S.engine] + encodeURIComponent(q);
}
$("searchForm").addEventListener("submit", (e) => { e.preventDefault(); const q = $("searchInput").value.trim(); if (q) go(q); });
$("startSearch").addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.value.trim()) go(e.target.value.trim()); });

// ---------- Boot ----------
store.get(["settings", "sites", "wallpaper", "notes", "todos"]).then((r) => {
  S = { ...structuredClone(DEFAULTS), ...(r.settings || {}) };
  S.widgets = { ...DEFAULTS.widgets, ...(S.widgets || {}) };
  if (Array.isArray(r.sites)) SITES = r.sites;
  WALLPAPER = r.wallpaper || null;
  NOTES = r.notes || "";
  TODOS = r.todos || [];
  render();
});
setInterval(tick, 1000);
