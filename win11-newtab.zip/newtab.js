const SITES = [
  { fa: "گوگل", en: "Google", url: "https://www.google.com", color: "#4285F4" },
  { fa: "یوتیوب", en: "YouTube", url: "https://www.youtube.com", color: "#FF0000" },
  { fa: "جیمیل", en: "Gmail", url: "https://mail.google.com", color: "#EA4335" },
  { fa: "گیت‌هاب", en: "GitHub", url: "https://github.com", color: "#333" },
  { fa: "ویکی‌پدیا", en: "Wikipedia", url: "https://wikipedia.org", color: "#6b6b6b" },
  { fa: "اینستاگرام", en: "Instagram", url: "https://www.instagram.com", color: "#C13584" },
  { fa: "تلگرام", en: "Telegram", url: "https://web.telegram.org", color: "#0088cc" },
  { fa: "X", en: "X", url: "https://x.com", color: "#000" },
  { fa: "لینکدین", en: "LinkedIn", url: "https://www.linkedin.com", color: "#0A66C2" },
  { fa: "اسپاتیفای", en: "Spotify", url: "https://open.spotify.com", color: "#1DB954" },
  { fa: "نقشه", en: "Maps", url: "https://www.google.com/maps", color: "#34A853" },
  { fa: "ترجمه", en: "Translate", url: "https://translate.google.com", color: "#4B8BF5" },
];

const I18N = {
  fa: {
    title: "تب جدید", search: "جستجو در وب...", startSearch: "جستجو...", pinned: "سایت‌های منتخب",
    settings: "تنظیمات", language: "زبان", engine: "موتور جستجو", calendar: "تقویم",
    persian: "شمسی", gregorian: "میلادی", hour24: "ساعت ۲۴ ساعته", seconds: "نمایش ثانیه",
    showShortcuts: "نمایش میانبرها", blur: "تاری پس‌زمینه", reset: "بازگردانی پیش‌فرض",
    start: "استارت", searchBtn: "جستجو",
  },
  en: {
    title: "New Tab", search: "Search the web...", startSearch: "Search...", pinned: "Pinned sites",
    settings: "Settings", language: "Language", engine: "Search engine", calendar: "Calendar",
    persian: "Persian (Solar)", gregorian: "Gregorian", hour24: "24-hour clock", seconds: "Show seconds",
    showShortcuts: "Show shortcuts", blur: "Wallpaper blur", reset: "Reset to defaults",
    start: "Start", searchBtn: "Search",
  },
};

const ENGINES = {
  google: "https://www.google.com/search?q=",
  bing: "https://www.bing.com/search?q=",
  duck: "https://duckduckgo.com/?q=",
};

const DEFAULTS = { lang: "fa", engine: "google", cal: "persian", h24: true, sec: false, short: true, blur: 0 };
let S = { ...DEFAULTS };

const hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
function load(cb) {
  if (hasChrome) chrome.storage.local.get("settings", (r) => cb(r.settings || {}));
  else cb(JSON.parse(localStorage.getItem("settings") || "{}"));
}
function save() {
  if (hasChrome) chrome.storage.local.set({ settings: S });
  else localStorage.setItem("settings", JSON.stringify(S));
}

const $ = (id) => document.getElementById(id);

function locale() {
  const base = S.lang === "fa" ? "fa-IR" : "en-US";
  return `${base}-u-ca-${S.cal}`;
}

function tick() {
  const now = new Date();
  const opts = { hour: "2-digit", minute: "2-digit", hour12: !S.h24 };
  if (S.sec) opts.second = "2-digit";
  const time = now.toLocaleTimeString(locale(), opts);
  $("clock").textContent = time;
  $("date").textContent = now.toLocaleDateString(locale(), { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  $("trayTime").textContent = now.toLocaleTimeString(locale(), { hour: "2-digit", minute: "2-digit", hour12: !S.h24 });
  $("trayDate").textContent = now.toLocaleDateString(locale());
}

function tile(site) {
  const d = document.createElement("div");
  d.className = "tile";
  d.style.background = site.color;
  d.textContent = site[S.lang][0];
  return d;
}
function link(site, cls) {
  const a = document.createElement("a");
  a.className = cls; a.href = site.url;
  a.appendChild(tile(site));
  a.appendChild(Object.assign(document.createElement("span"), { textContent: site[S.lang] }));
  return a;
}

function render() {
  const t = I18N[S.lang];
  document.documentElement.lang = S.lang;
  document.documentElement.dir = S.lang === "fa" ? "rtl" : "ltr";
  document.title = t.title;
  $("searchInput").placeholder = t.search;
  $("startSearch").placeholder = t.startSearch;
  $("startBtn").title = t.start;
  $("taskSearchBtn").title = t.searchBtn;
  $("settingsBtn").title = t.settings;
  document.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t[el.dataset.i18n]; });

  const sc = $("shortcuts");
  sc.innerHTML = "";
  sc.style.display = S.short ? "" : "none";
  SITES.slice(0, 6).forEach((s) => sc.appendChild(link(s, "shortcut")));
  const grid = $("startGrid");
  grid.innerHTML = "";
  SITES.forEach((s) => grid.appendChild(link(s, "start-item")));

  $("wallpaper").style.filter = S.blur ? `blur(${S.blur}px)` : "";
  $("wallpaper").style.transform = S.blur ? "scale(1.05)" : "";

  $("setLang").value = S.lang;
  $("setEngine").value = S.engine;
  $("setCal").value = S.cal;
  $("setH24").checked = S.h24;
  $("setSec").checked = S.sec;
  $("setShort").checked = S.short;
  $("setBlur").value = S.blur;
  tick();
}

function bind(id, key, prop = "value", cast = (v) => v) {
  $(id).addEventListener("input", (e) => { S[key] = cast(e.target[prop]); save(); render(); });
}
bind("setLang", "lang");
bind("setEngine", "engine");
bind("setCal", "cal");
bind("setH24", "h24", "checked");
bind("setSec", "sec", "checked");
bind("setShort", "short", "checked");
bind("setBlur", "blur", "value", Number);
$("resetSettings").addEventListener("click", () => { S = { ...DEFAULTS }; save(); render(); });

function go(q) {
  const isUrl = /^https?:\/\//.test(q) || (/^[\w-]+(\.[\w-]+)+/.test(q) && !q.includes(" "));
  location.href = isUrl ? (q.startsWith("http") ? q : "https://" + q) : ENGINES[S.engine] + encodeURIComponent(q);
}
$("searchForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const q = $("searchInput").value.trim();
  if (q) go(q);
});
$("startSearch").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && e.target.value.trim()) go(e.target.value.trim());
});

const menu = $("startMenu");
const panel = $("settingsPanel");
$("startBtn").addEventListener("click", (e) => { e.stopPropagation(); panel.classList.add("hidden"); menu.classList.toggle("hidden"); });
$("settingsBtn").addEventListener("click", (e) => { e.stopPropagation(); menu.classList.add("hidden"); panel.classList.toggle("hidden"); });
$("closeSettings").addEventListener("click", () => panel.classList.add("hidden"));
$("taskSearchBtn").addEventListener("click", () => $("searchInput").focus());
document.addEventListener("click", (e) => {
  if (!menu.contains(e.target)) menu.classList.add("hidden");
  if (!panel.contains(e.target)) panel.classList.add("hidden");
});

load((saved) => { S = { ...DEFAULTS, ...saved }; render(); });
setInterval(tick, 1000);
